var styles = [ {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.9.1",
  "target_cytoscapejs_version" : "~2.1",
  "title" : "default",
  "style" : [ {
    "selector" : "node",
    "css" : {
      "width" : 35.0,
      "font-family" : "SansSerif.plain",
      "font-weight" : "normal",
      "background-color" : "rgb(137,208,245)",
      "text-opacity" : 1.0,
      "font-size" : 12,
      "shape" : "roundrectangle",
      "border-opacity" : 1.0,
      "background-opacity" : 1.0,
      "color" : "rgb(0,0,0)",
      "border-width" : 0.0,
      "text-valign" : "center",
      "text-halign" : "center",
      "border-color" : "rgb(204,204,204)",
      "height" : 35.0,
      "content" : "data(name)"
    }
  }, {
    "selector" : "node[BetweennessCentrality > 1]",
    "css" : {
      "font-size" : 1
    }
  }, {
    "selector" : "node[BetweennessCentrality = 1]",
    "css" : {
      "font-size" : 127
    }
  }, {
    "selector" : "node[BetweennessCentrality > 0][BetweennessCentrality < 1]",
    "css" : {
      "font-size" : "mapData(BetweennessCentrality,0,1,19,127)"
    }
  }, {
    "selector" : "node[BetweennessCentrality = 0]",
    "css" : {
      "font-size" : 19
    }
  }, {
    "selector" : "node[BetweennessCentrality < 0]",
    "css" : {
      "font-size" : 1
    }
  }, {
    "selector" : "node[Column_1 = 'Music:']",
    "css" : {
      "font-family" : "Arial Black",
      "font-weight" : "normal"
    }
  }, {
    "selector" : "node[Column_1 = 'Music:']",
    "css" : {
      "background-color" : "rgb(253,141,60)"
    }
  }, {
    "selector" : "node:selected",
    "css" : {
      "background-color" : "rgb(255,255,0)"
    }
  }, {
    "selector" : "edge",
    "css" : {
      "target-arrow-shape" : "none",
      "width" : 2.0,
      "text-opacity" : 1.0,
      "source-arrow-color" : "rgb(0,0,0)",
      "font-size" : 10,
      "font-family" : "Dialog.plain",
      "font-weight" : "normal",
      "color" : "rgb(0,0,0)",
      "line-color" : "rgb(132,132,132)",
      "line-style" : "solid",
      "source-arrow-shape" : "none",
      "target-arrow-color" : "rgb(0,0,0)",
      "opacity" : 1.0,
      "content" : ""
    }
  }, {
    "selector" : "edge[Column_4 > 12]",
    "css" : {
      "width" : 1.0
    }
  }, {
    "selector" : "edge[Column_4 = 12]",
    "css" : {
      "width" : 30.0
    }
  }, {
    "selector" : "edge[Column_4 > 1][Column_4 < 12]",
    "css" : {
      "width" : "mapData(Column_4,1,12,1.7073170731707317,30.0)"
    }
  }, {
    "selector" : "edge[Column_4 = 1]",
    "css" : {
      "width" : 1.7073170731707317
    }
  }, {
    "selector" : "edge[Column_4 < 1]",
    "css" : {
      "width" : 1.0
    }
  }, {
    "selector" : "edge[Column_4 > 12]",
    "css" : {
      "line-color" : "rgb(1,70,54)"
    }
  }, {
    "selector" : "edge[Column_4 = 12]",
    "css" : {
      "line-color" : "rgb(1,108,89)"
    }
  }, {
    "selector" : "edge[Column_4 > 6.53306645][Column_4 < 12]",
    "css" : {
      "line-color" : "mapData(Column_4,6.53306645,12,rgb(103,169,207),rgb(1,108,89))"
    }
  }, {
    "selector" : "edge[Column_4 > 1][Column_4 < 6.53306645]",
    "css" : {
      "line-color" : "mapData(Column_4,1,6.53306645,rgb(227,26,28),rgb(103,169,207))"
    }
  }, {
    "selector" : "edge[Column_4 = 1]",
    "css" : {
      "line-color" : "rgb(227,26,28)"
    }
  }, {
    "selector" : "edge[Column_4 < 1]",
    "css" : {
      "line-color" : "rgb(255,247,251)"
    }
  }, {
    "selector" : "edge:selected",
    "css" : {
      "line-color" : "rgb(255,0,0)"
    }
  } ]
} ]